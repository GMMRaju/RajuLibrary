/* author:Murali
 * 
 */

package au.com.ebay.pages;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Ebay {

	public Properties p = new Properties();

	
	 // The below script describes for item search on ebay site
	 

	public void itemSearch(WebDriver driver, String itemName) throws Exception {

		p.load(new FileReader(".//resources//configlocal.properties"));

		driver.findElement(By.xpath("//input[@placeholder='Search for anything']")).sendKeys(itemName);
		driver.findElement(By.xpath(p.getProperty("SEARCH_BUTTON_XPATH"))).click();
		Thread.sleep(3000);

		// Select first item from the search results
		driver.findElement(By.xpath(p.getProperty("SEARCH_ITEM_XPATH"))).click();
		

	}

	// Below code describes select first item from search results

	public void selectItem(WebDriver driver) throws Exception {
		p.load(new FileReader(".//resources//configlocal.properties"));
		// Select Items color and quanlity
		WebElement colordropdown = driver.findElement(By.xpath(p.getProperty("SEARCH_ITEM_COLOR_XPATH")));
		Select selectColor = new Select(colordropdown);
		selectColor.selectByValue("0");

		driver.findElement(By.xpath(p.getProperty("SEARCH_ITEM_CLEAR_XPATH"))).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath(p.getProperty("SEARCH_ITEM_QUANTY_XPATH"))).sendKeys("2");
	}

	// Below script describes Add to Cart the Selected item

	public void addItemToCart(WebDriver driver) throws Exception {
		p.load(new FileReader(".//resources//configlocal.properties"));
		Thread.sleep(2000);
		driver.findElement(By.xpath(p.getProperty("ADDCART_XPATH"))).click();
		Thread.sleep(5000);
	}

	// Below script describes the CheckOut for added items to the cart

	public void checkOut(WebDriver driver) throws Exception {
		p.load(new FileReader(".//resources//configlocal.properties"));
		// CheckOut
		driver.findElement(By.xpath(p.getProperty("CHECKOUT_BUTTON_XPATH"))).click();
		Thread.sleep(1000);
		Boolean isDisplayed = driver.findElement(By.xpath(p.getProperty("MESSAGE_XPATH"))).isDisplayed();

		if (isDisplayed) {
			System.out.println("Checkout Page is displayed");
		} else {
			System.out.println("Checkout Page is not displayed");
		}
	}

}
