/* author: Murali
 * 
 */

package au.com.ebay.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Utils {
	public static Properties p = new Properties();

	// Below script describes to LaunchTheBrowser

	public static void launchTheBrowser(WebDriver driver) throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.ebay.com.au/");
		Thread.sleep(2000);

	}

	// Below script describes Login in to ebay application

	public static void login(WebDriver driver) throws Exception {
		p.load(new FileReader(".//resources//configlocal.properties"));
		// Sign in in to the ebay Application
		driver.findElement(By.xpath(p.getProperty("SIGNIN_XPATH"))).click();
		driver.findElement(By.xpath(p.getProperty("USERID_XPATH"))).sendKeys("testwooliesxcode@gmail.com");
		driver.findElement(By.xpath(p.getProperty("PASSWORD_XPATH"))).sendKeys("test@1234");
		driver.findElement(By.xpath(p.getProperty("SIGNIN_BUTTON_XPATH"))).click();
		Thread.sleep(2000);
	}

	// Below script describes Close the browser

	public static void logout(WebDriver driver) {
		driver.close();
	}

}
