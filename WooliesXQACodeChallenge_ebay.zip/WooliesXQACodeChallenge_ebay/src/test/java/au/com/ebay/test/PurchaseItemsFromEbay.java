/*author:murali
 * 
 */
package au.com.ebay.test;

import java.io.FileReader;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import au.com.ebay.pages.Ebay;
import au.com.ebay.utils.Utils;

public class PurchaseItemsFromEbay {

	public Properties p = new Properties();
	
	//Below script describes Run the test suite

	@Test
	public void purchaseItemsFromEbay() throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		Utils.launchTheBrowser(driver);
		Utils.login(driver);
		Ebay ebay = new Ebay();
		ebay.itemSearch(driver, "Wireless Earphones");
		ebay.selectItem(driver);
		ebay.addItemToCart(driver);
		ebay.checkOut(driver);
		Utils.logout(driver);
	}

}
