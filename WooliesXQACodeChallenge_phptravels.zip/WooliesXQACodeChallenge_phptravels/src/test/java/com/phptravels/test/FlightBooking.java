/*author:murali
 * 
 */

package com.phptravels.test;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.phptravels.pages.AmaduesFlightsModule;
import com.phptravels.pages.ExpediaHotelsModule;
import com.phptravels.utils.Utils;

public class FlightBooking {

	public Properties p = new Properties();
	
	//The below script describes run the TestSuite

	@Test
	public void flightBooking() throws Exception {

		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		Utils.launchTheBrowser(driver);
		AmaduesFlightsModule amafl = new AmaduesFlightsModule();
		amafl.loginToFlightModule(driver);
		amafl.searchFlight(driver);
		Utils.logout(driver);

	}

}
