/*author: murali
 * 
 */

package com.phptravels.test;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.phptravels.pages.ExpediaHotelsModule;
import com.phptravels.utils.Utils;

public class HotelBooking {

	public Properties p = new Properties();
	
	//The below script describes run the testsuite

	@Test
	public void hotelBooking() throws Exception {

		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		Utils.launchTheBrowser(driver);
		ExpediaHotelsModule exphot = new ExpediaHotelsModule();
		exphot.loginToHotelModule(driver);
		exphot.searchHotel(driver);
		Utils.logout(driver);

	}

}
