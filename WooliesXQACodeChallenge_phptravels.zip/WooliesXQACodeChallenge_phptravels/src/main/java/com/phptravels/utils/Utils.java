/*author:murali
 * 
 */

package com.phptravels.utils;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

public class Utils {

	public static Properties p = new Properties();
	
	//The below script describes for launching the browser

	public static void launchTheBrowser(WebDriver driver) throws Exception {

		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.phptravels.com/demo/");
		Thread.sleep(2000);

	}
	
	//The below script describes close the browser
	
	public static void logout(WebDriver driver) throws Exception {
		Thread.sleep(2000);
		driver.quit();
	}

}
