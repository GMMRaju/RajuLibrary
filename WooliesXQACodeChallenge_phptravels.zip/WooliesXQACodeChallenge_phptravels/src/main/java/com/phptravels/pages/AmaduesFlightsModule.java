/*author:murali
 * 
 */

package com.phptravels.pages;

import java.util.ArrayList;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class AmaduesFlightsModule {

	public Properties p = new Properties();
	
	//The below script describes Login in to Flight Module

	public void loginToFlightModule(WebDriver driver) throws Exception {

		driver.findElement(By.xpath("//button[@id='onesignal-popover-cancel-button']")).click();

		driver.findElement(By.xpath("//div[@id='PopupSignupForm_0']/child::div[2]/div[1]")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath(
				"//div[contains(text(),'Expedia Hotels Module')]/following::div[32]/a[contains(text(),'Check Demo')]"))
				.click();
		Thread.sleep(5000);
		Set<String> b = driver.getWindowHandles();

		ArrayList<String> c = new ArrayList<String>(b);

		driver.switchTo().window(c.get(1));
		

	}
	
	//The below script describes Search for the Flights

	public void searchFlight(WebDriver driver) throws Exception {

		driver.findElement(By.xpath("//div[@id='s2id_origin']//a[@class='select2-choice select2-default']")).click();
		driver.findElement(By.xpath("//div[@id='select2-drop-mask']/following::div/child::div/child::input[1]"))
				.sendKeys("sydney");

		driver.findElement(By.xpath(
				"//div[@id='select2-drop-mask']/following::div/child::ul/li[2]/div[contains(text(),'Kingsford')]"))
				.click();

		driver.findElement(By.xpath("//div[@id='s2id_destination']//a[@class='select2-choice select2-default']"))
				.click();
		driver.findElement(By.xpath("//div[13]//div[1]//input[1]")).sendKeys("hyderabad");

		driver.findElement(
				By.xpath("//footer[@id='footer']/following::div[28]/following::ul/li/div[contains(text(),'HDD')]"))
				.click();
		
		Thread.sleep(2000);
		
		WebElement wayselect = driver.findElement(By.xpath("//select[@name='triptype']"));
		Select selectway = new Select(wayselect);
		selectway.selectByIndex(1);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//div[10]//div[1]//table[1]//tbody[1]//tr[6]//td[7] ")).click();
		Thread.sleep(2000);
		
		WebElement classselect = driver.findElement(By.xpath("//select[@name='cabinclass']"));
		Select selectclass = new Select(classselect);
		selectclass.selectByIndex(1);
		Thread.sleep(2000);
		
		WebElement stopselect = driver.findElement(By.xpath("//select[@name='nonStop']"));
		Select selectstop = new Select(stopselect);
		selectstop.selectByIndex(1);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='totalManualPassenger']")).click();
		Thread.sleep(2000);
		
		WebElement adselect = driver.findElement(By.xpath("//select[@name='madult']"));
		Select selectad = new Select(adselect);
		selectad.selectByValue("3");
		Thread.sleep(2000);
		
		WebElement chselect = driver.findElement(By.xpath("//select[@name='mchildren']"));
		Select selectch = new Select(chselect);
		selectch.selectByValue("2");

		driver.findElement(By.xpath("//button[@id='sumManualPassenger']")).click();

		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[contains(text(),'Search')]")).click();
		Thread.sleep(5000);

		Boolean result = driver
				.findElement(By.xpath("//div[@id='body-section']/child::div[3]/div/child::div[3]/child::div[2]/div[1]"))
				.isDisplayed();

		if (result) {
			System.out.println("There are no flight for search dates and please search with different dates");
		} else {
			System.out.println("Displayed search flight details");
		}

	}

}
