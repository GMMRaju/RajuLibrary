/*author:murali
 * 
 */

package com.phptravels.pages;

import java.util.ArrayList;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ExpediaHotelsModule {

	public Properties p = new Properties();
	
	//The below script describes Login in to Hotel Module

	public void loginToHotelModule(WebDriver driver) throws Exception {

		driver.findElement(By.xpath("//button[@id='onesignal-popover-cancel-button']")).click();

		driver.findElement(By.xpath(
				"//div[contains(text(),'Expedia Hotels Module')]/following::div[8]/a[contains(text(),'Check Demo')]"))
				.click();
		Thread.sleep(5000);
		Set<String> b = driver.getWindowHandles();

		ArrayList<String> c = new ArrayList<String>(b);

		driver.switchTo().window(c.get(1));
	
	}

	//The below script describes search for Hotels
	
	public void searchHotel(WebDriver driver) throws Exception {
		
		driver.findElement(By.xpath("//input[@placeholder='Search by Hotel or City Name']")).sendKeys("sydney");
		driver.findElement(By.xpath("//input[@placeholder='Check in']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(
				"//footer[@id='footer']/following::div[16]/div[1]/table[1]/tbody[1]/tr[5]/td[contains(text(),'1')]"))
				.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(
				"//footer[@id='footer']/following::div[20]/div[1]/table[1]/tbody[1]/tr[1]/td[contains(text(),'6')]"))
				.click();
		driver.findElement(By.xpath("//input[@id='totalGuestsInput']")).click();
		driver.findElement(By.xpath("//button[@id='adultPlusBtn']")).click();
		driver.findElement(By.xpath("//button[@id='childPlusBtn']")).click();
		driver.findElement(By.xpath("//button[contains(text(),'Search')]")).click();
		Boolean b1 = driver.findElement(By.xpath("//h1[contains(text(),'No Results Found')]")).isDisplayed();

		if (b1) {
			System.out.println("There are No Hotels available, please use different criteria");
		} else {
			System.out.println("Hotel details displayed");
		}

		driver.findElement(By.xpath("//input[@id='5']/..")).click();
		driver.findElement(By.xpath("//input[@id='suite']/..")).click();
		driver.findElement(By.xpath("//input[@id='bed']/..")).click();
		driver.findElement(By.xpath("//button[@id='searchform']")).click();

		Boolean b2 = driver.findElement(By.xpath("//h1[contains(text(),'No Results Found')]")).isDisplayed();

		if (b2) {
			System.out.println("There are No Hotels available, please use different dates");
		} else {
			System.out.println("Hotel details are displayed");
		}

	}

}
