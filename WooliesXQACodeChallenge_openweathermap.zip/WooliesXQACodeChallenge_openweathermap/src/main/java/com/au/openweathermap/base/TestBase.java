package com.au.openweathermap.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class TestBase {
	
	public Properties prop;
	
	public  TestBase()
	{
		try {
			prop = new Properties();
			
			prop.load(new FileReader(".//resources//configlocal.properties"));
			
			//FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+ "\\src\\main\\java\\com\\au\\openweathermap\\config\\config.properteis");
			//prop.load(ip);
			
			
			
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
