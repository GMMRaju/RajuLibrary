package com.au.client;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

public class RestClient {

	// 1.GET Method

	public void get(String url) throws ClientProtocolException, IOException {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpGet httpget = new HttpGet(url); //http get request
		CloseableHttpResponse response = httpClient.execute(httpget); //hit the GET URL
		
		//a.Status Code
		int statusCode = response.getStatusLine().getStatusCode();
		System.out.println("Status code......."+statusCode);
		
		//b.Json String
		String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
		
		JSONObject responsejson = new JSONObject(responseString);
		System.out.println("Response Json from API------>"+responsejson);
		String cityname = responsejson.getString("name");
		System.out.println("Weather Requested city--->   "+cityname);
		//Float temp1 = responsejson.getFloat("temp_min");
		//System.out.println("Temparature in "+cityname+temp1+"greater than 10 degrees");
		
		//c.All Headers
		Header[] headersArray = response.getAllHeaders();
		
		HashMap<String, String> allHeaders = new HashMap<String, String>();
		
		for(Header header : headersArray) {
			
			allHeaders.put(header.getName(),header.getValue());
		}
		System.out.println("Headers Array---->"+allHeaders);
	}

}
